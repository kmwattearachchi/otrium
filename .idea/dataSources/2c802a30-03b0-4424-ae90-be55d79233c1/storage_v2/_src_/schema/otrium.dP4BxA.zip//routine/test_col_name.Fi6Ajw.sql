create
    definer = root@localhost procedure test_col_name()
BEGIN
    SET @stmt := CONCAT("SELECT 1 AS '", CURDATE(), "'");

    PREPARE p_stmt FROM @stmt;
    EXECUTE p_stmt;
    DEALLOCATE PREPARE p_stmt;
END;

